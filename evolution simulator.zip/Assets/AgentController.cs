﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using System.IO;

public class AgentController : MonoBehaviour
{
    public int waterGathered = 3;
    public int foodGathered = 3;

    public int waterUsed = 1;
    public int foodUsed = 2;

    public int startWater = 1;
    public int startFood = 2;

    [Min(2)]
    public int numberOfAgents = 10;
    public int numberOfCycles = 100;

    public float startPercentage = 50;

    int cyclesPassed = 0;

    Agent[] agents;

    Agent bestAgent;
    Agent secondBestAgent;

    //create all agents and start a simulation cycle
    void Start()
    {
        agents = new Agent[numberOfAgents];

        for(int i = 0; i < agents.Count(); i++)
        {
            Agent startAgent = new Agent();
            startAgent.SetPercentage(startPercentage,this);
            agents[i] = startAgent;
        }
        bestAgent = agents[0];
        secondBestAgent = agents[1];
        BeginCycle();
    }

    //start the simulation of each agent. After it is finished it assigns the best and secondbest agents.
    //it does this for the defined number of cycles
    void BeginCycle()
    {
        if(cyclesPassed < numberOfCycles)
        {
            StartAgents();
            ResetBestAgents();           
            foreach (Agent agent in agents)
            {
                if (bestAgent != null)
                {
                    if (agent.lifeTime > secondBestAgent.lifeTime)
                    {
                        if (agent.lifeTime > bestAgent.lifeTime)
                        {
                            secondBestAgent = bestAgent;
                            bestAgent = agent;
                        }
                        else
                        {
                            secondBestAgent = agent;
                        }   
                    }
                }
                else
                {
                    bestAgent = agent;
                    secondBestAgent = agent;
                }
            }
            Debug.Log("lifetime " + bestAgent.lifeTime + " waterpercentage: " + bestAgent.waterGatherPercentage);
            File.AppendAllText("data.txt", bestAgent.waterGatherPercentage.ToString() + "\n");
            File.AppendAllText("data2.txt", bestAgent.lifeTime.ToString() + "\n");
            CreateNextCycle();
            cyclesPassed += 1;
            BeginCycle();
        }

    }

    //starts all agents simulations
    void StartAgents()
    {
        foreach (Agent agent in agents)
        {
            agent.StartNextSimulation();
        }
    }

    //clear the best agent and secondbest agent
    void ResetBestAgents()
    {
        bestAgent = null;
        secondBestAgent = null;
    }

    //half the agents are based on the best agents the other half are secondbestagents
    //foreach agent it sets its values to the agent it is based on, but it has a slight variation.
    void CreateNextCycle()
    {
        for (int i = 0; i < agents.Count(); i++)
        {
            if(i < agents.Count() / 2)
            {
                agents[i] = new Agent();
                agents[i].Begin(bestAgent, this);
            }
            else
            {
                agents[i] = new Agent();
                agents[i].Begin(secondBestAgent, this);
            }
        }
    }

    //if e is pressed go through 200 cycles
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.E))
        {
            numberOfCycles += 200;
            BeginCycle();
        }
    }
}
