﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Diagnostics;

public class Agent
{
    public float waterGatherPercentage;
    public float foodGatherPercentage;
    public int lifeTime;

    int foodStored;
    int waterStored;

    int foodUsed;
    int waterUsed;

    int foodGathered;
    int waterGathered;

    int amountOfTimesWaterChosen = 1;
    int amountOfTimesFoodChosen = 1;

    //sets the initial variables based on a agent
    public void SetPercentage(float waterPercentage ,AgentController agentController)
    {
        foodStored = agentController.startFood;
        waterStored = agentController.startWater;

        foodUsed = agentController.foodUsed;
        waterUsed = agentController.waterUsed;

        foodGathered = agentController.foodGathered;
        waterGathered = agentController.waterGathered;

        waterGatherPercentage = waterPercentage;
        foodGatherPercentage = 100 - waterGatherPercentage;
    }

    //sets variables based on a agent with a slight variation
    public void Begin(Agent parentAgent, AgentController agentController)
    {
        foodStored = agentController.startFood;
        waterStored = agentController.startWater;

        foodUsed = agentController.foodUsed;
        waterUsed = agentController.waterUsed;

        foodGathered = agentController.foodGathered;
        waterGathered = agentController.waterGathered;

        waterGatherPercentage = parentAgent.waterGatherPercentage + Random.Range(-0.5f, 0.5f);
        waterGatherPercentage = Mathf.Clamp(waterGatherPercentage, 0, 100);

        foodGatherPercentage = 100 - waterGatherPercentage;
    }

    //each turn the agent gathers water or food
    //each turn the agent loses certain water and food
    //if water or food reaches 0 the agent dies and the lifetime is determined
    public void StartNextSimulation()
    {   if(amountOfTimesFoodChosen == 0 && amountOfTimesWaterChosen == 0)
        {
            int randomN = Random.Range(0, 100);
            if(randomN <= waterGatherPercentage)
            {
                amountOfTimesWaterChosen += 1;
                waterStored += waterGathered;
            }
            else
            {
                amountOfTimesFoodChosen += 1;
                foodStored += foodGathered;
            }
        }
        else
        {
            float waterChosenPercentage = ((float)amountOfTimesWaterChosen / (amountOfTimesWaterChosen + amountOfTimesFoodChosen)) * 100;
            if (waterChosenPercentage < waterGatherPercentage)
            {
                amountOfTimesWaterChosen += 1;
                waterStored += waterGathered;
            }
            else
            {
                amountOfTimesFoodChosen += 1;
                foodStored += foodGathered;
            }
        }
        if(foodStored - foodUsed >= 0 && waterStored - waterUsed >= 0)
        {
            foodStored -= foodUsed;
            waterStored -= waterUsed;
            lifeTime += 1;
            if(lifeTime < 5000)
            {
                StartNextSimulation();
            }
        }
    }
}
